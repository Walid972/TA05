from tkinter import *
import tkinter
from tkinter import ttk
import json
from PIL import ImageTk, Image
from tkinter import messagebox

i = 3

with open("credencials.json") as fitxero: 
    credencials = json.load(fitxero)
    usuari = credencials ['usuari']
    contra= credencials ['Contra']

def boton_bienvenida(): #ventana general de compra
    with open("zapatillas.json") as fitxero: #cargar las imagenes
        productos = json.load(fitxero)

    imagen_carrito = PhotoImage(file="carr2.png")
    añadirCarrito = PhotoImage(file="carrrr2.png")
    carrito = []

    def agregar_al_carrito(producto): #Agrega los productos seleccionados al carrito
        carrito.append(producto)
        mensaje = Entry(root, width=50)
        mensaje.insert(0, f"{producto['nombre']} ha sido agregado al carrito correctamente!")
        mensaje.place(x=1220, y=20)  

    def ver_carrito(): #Ventana del carrito

        def eliminar_del_carrito(producto): #Elimina el producto del carrito y refresca la ventana del carrito
            carrito.remove(producto)
            messagebox.showinfo("Éxito", f"{producto['nombre']} ha sido eliminado del carrito correctamente!", parent=carrito_window)
            carrito_window.destroy()
            ver_carrito()

        def aceptar_tramite():#escribe la nueva compra efectuada a compra.json
            data = [{"carrito": carrito, "total": total}]
            with open("compra.json", "w") as fitxero:
                fitxero.write(json.dumps(data, indent=3) + "\n")
            messagebox.showinfo("Éxito", "El trámite se ejecutó con éxito", parent=carrito_window)
            mostrar_compras_json()
                
        def mostrar_compras_json():
        # Abre el archivo 'compras.json' en modo lectura
            with open("compra.json", "r") as f:
                # Carga el contenido del archivo en la variable 'compras'
                compras = json.load(f)
            # Iterar sobre cada elemento de la lista 'compras'
            for compra in compras:
                # Imprime en la consola el contenido de cada elemento de la lista 'compras' con una indentación de 6 espacios
                print(json.dumps(compra, indent=3))

        if carrito:  # Comprueba si el carrito está vacío
            total = sum([producto['precio'] for producto in carrito])
        else:
            total = 0  # Si el carrito está vacío, el total es 0

        carrito_window = Toplevel(root)
        carrito_window.title("Carrito")
        carrito_window.geometry("400x700") 
        Label(carrito_window, text="Productos en el carrito:", font=('Georgia', 11)).pack()
        
        # Iterar sobre cada producto en el carrito
        for producto in carrito:
            # Abrir la imagen del producto y redimensionarla
            img = Image.open(producto['imagen'])
            img = img.resize((125, 100), Image.LANCZOS)
            # Convertir la imagen en un objeto PhotoImage de Tkinter
            img = ImageTk.PhotoImage(img)
            # Crear un nuevo panel de imagen y agregar la imagen al panel
            panel = Label(carrito_window, image=img)
            panel.image = img
            panel.pack()
            # Crear un nuevo label para mostrar el nombre y el precio del producto
            Label(carrito_window, text=f"{producto['nombre']} - ${producto['precio']}", font=('Georgia', 11)).pack()
            # Crear un nuevo botón para eliminar el producto del carrito
            eliminar_button = Button(carrito_window, text="Eliminar del carrito", command=lambda p=producto: eliminar_del_carrito(p))
            eliminar_button.pack()
        # Crear un nuevo label para mostrar el total del carrito
        Label(carrito_window, text=f"\nTotal: ${total:.2f}", font=('Georgia', 11)).pack()
        # Crear un nuevo botón para aceptar el trámite
        tramite_button = Button(carrito_window, text="Aceptar trámite", command=aceptar_tramite)
        tramite_button.pack()

    root = Toplevel()  
    root.title("Vike")
    root.geometry("2500x2500")
    root.configure(background='white')

    tit= Label (root, text="Vike", fg="black", bg="white",font=('Georgia', 70)) 
    tit.place(x=650, y=20)
    carrito_button = Button(root, image=imagen_carrito, width=40, height=40, command=ver_carrito)
    carrito_button.place(x=1350, y=40)
    
    contenedor_productos = tkinter.Frame(root, bg="white")  # Usa tkinter en lugar de ttk
    contenedor_productos.place(x=100, y=200)

    ancho_producto = 250  # Ancho del espacio para cada producto
    ancho_ventana = root.winfo_screenwidth()  # Ancho de la ventana
    columnas = ancho_ventana // ancho_producto  # Número de columnas

   # Variable global para almacenar la orientación actual
    orientacion = "columnas"

    # Define 'orientacion' como una lista con un solo elemento al inicio de tu script
    orientacion = ["columnas"]

    def mostrar_productos():
        # Primero, borra todos los widgets existentes en el contenedor
        for widget in contenedor_productos.winfo_children():
            widget.destroy()

        for i, producto in enumerate(productos):
            img = Image.open(producto['imagen'])
            img = img.resize((125, 100), Image.LANCZOS) 
            img = ImageTk.PhotoImage(img)
            panel = Label(contenedor_productos, image=img, bg="white")
            panel.image = img
            caracter= Label (contenedor_productos, text=f"{producto['nombre']} - ${producto['precio']}", fg="black", bg="white",font=('Georgia', 11))
            añadir=Button(contenedor_productos, image= añadirCarrito ,width=26, height=26, bg="white", fg="black", font=('Georgia', 10), command=lambda p=producto: agregar_al_carrito(p))

            if orientacion[0] == "columnas":
                panel.grid(row=i, column=0, padx=50)
                caracter.grid(row=i, column=1, padx=50)
                añadir.grid(row=i, column=2)
            else:  # Si la orientación es "filas"
                panel.grid(row=0, column=i*3, padx=50)
                caracter.grid(row=1, column=i*3, padx=10)
                añadir.grid(row=2, column=i*3)

    def cambiar_orientacion():
        orientacion[0] = "filas" if orientacion[0] == "columnas" else "columnas"
        mostrar_productos()

    boton_cambiar = Button(root, text="Cambiar orientación", command=cambiar_orientacion)
    boton_cambiar.place(x=1350, y=90)
    mostrar_productos()

    root.mainloop()

def establecer_contra(): 
    global Nova_contra
    global contra
    global comu
    global usuari
    nueva_contra = Nova_contra.get()
    if len(nueva_contra) < 8:
        comu.delete('1.0', END)
        comu.insert("end", "La contrasenya no compleix amb els requisits. Ha de tenir almenys 8 caràcters.")
    elif not any(i.isalpha() for i in nueva_contra):
        comu.delete('1.0', END)
        comu.insert("end", "La contrasenya no compleix amb els requisits. Ha de contenir almenys una lletra.")
    else:
        contra = nueva_contra
        comu.delete('1.0', END)
        comu.insert("end", "La contrasenya compleix amb els requisits. La teva contrasenya s'ha actualitzat correctament.")
        with open("credencials.json", "w") as f:  
            json.dump({'usuari': usuari, 'Contra': contra}, f)

def verificar(): # Funcio la qual s'encarrega de la verificació del usuari abans de cambiar de contrasenya
    global Verifi
    global contra
    global new_window
    global Nova_contra
    global comu
    if Verifi.get() == contra:
        instrucciones=Label (new_window, text="La teva nova contrasenya ha de contenir 8 caracters o més i com a mínim una lletra", fg="black", bg="white", font=('Georgia', 10))
        instrucciones.place(x=500, y=500)
        Nova_contra = Entry(new_window, fg="blue", bg="white", width=30)
        Nova_contra.place(x=500, y=350)
        boton_nova=Button(new_window, text="Prem per establir la teva nova contrasenya",width=35, height=2, bg="blue", fg="white", font=('Georgia', 10), command= establecer_contra)
        boton_nova.place(x=500, y=400)
        comu=Text(new_window, fg="blue", bg="white", width=50, height=2)
        comu.place(x=500, y=450)
        info= Label(new_window, text="Afegeix la teva nova contrasenya", fg="black", bg="white", font=('Georgia', 10))
        info.place(x=500, y=325)

def boton_pres(event): #Aquesta funció conte tota la parte de canvi de contraseña
    global contra
    global Verifi
    global new_window
    new_window = Toplevel(w)
    new_window.title("Canvi de contraseña")
    new_window.geometry("1400x1400")  
    new_window.configure(background='white')

    titulo = Label(new_window, text="Nova contrasenya", fg="black", bg="white", font=('Georgia', 45)) 
    titulo.place(x=500, y=5)  

    verif = Label(new_window, text="Per verificar posa la teva contrasenya actual:", fg="black", bg="white", font=('Georgia', 10))
    verif.place(x=500, y=112) 

    Verifi = Entry(new_window, fg="blue", bg="white", width=30)
    Verifi.place(x=500, y=137) 

    boton_verificar = Button(new_window, text="Verificar", command=verificar)
    boton_verificar.place(x=500, y=175) 


def boto_pres(event): #inicio de sesión
    global i
    global contra
    global usuari
    entryUsu_text = entryUsu.get()
    entryPwd_text = entryPwd.get()
    if entryUsu_text == usuari and entryPwd_text == contra: #si el usuario y contraseña son correctos que aparezca los suguientes botones: 
        text.insert("1.0", "Bienvenido " + entryUsu.get() + "\n")
        boton = Button(text="Prem aqui si vols cambiar la contrasenya", width=35, height=2, bg="blue", fg="white", font=('Georgia', 10))
        boton.bind("<Button-1>", boton_pres)
        boton.place(x=950, y=400)
        boton_bienvenid = Button(text="Prem aqui per continuar", width=35, height=2, bg="blue", fg="white", font=('Georgia', 10), command=boton_bienvenida)
        boton_bienvenid.place(x=950, y=450)
    else:
        i -= 1
        text.insert("2.0", "Contraseña o usuario incorrecto. Te quedan " + str(i) + " intento/s. " + "\n")
        if i <= 0:
            boto.config(state=DISABLED)
            boto.unbind("<Button-1>")

w = Tk() 
w.title("Iniciar Sesion")
w.geometry("2500x2500")
w.configure(background='white')

titul= Label (text="Vike", fg="black", bg="white", font=('Georgia', 90)) 
titul.place (x=625, y=10)

usu = Label (text="Inserta tu usuario: ", fg="black", bg="white",font=('Georgia', 11)) 
usu.place(x=650, y=235)
entryUsu= Entry ( fg="blue", bg="white", width=30) 
entryUsu.place(x=650, y=270)

pwd= Label (text="Inserta tu contraseña: ", fg="black", bg="white",font=('Georgia', 11)) 
pwd.place(x=650, y=335)
entryPwd= Entry ( fg="blue", bg="white", width=30, show="*") 
entryPwd.place(x=650, y=370)

boto = Button ( text= "Prem per iniciar sesió",width=26, height=2, bg="blue", fg="white", font=('Georgia', 10))
boto.bind( "<Button-1>", boto_pres)
boto.place( x=650, y=400)

text = Text ( fg= "black", bg="white", width=30, height=7) 
text.place(x=650,y=450)

w.mainloop()